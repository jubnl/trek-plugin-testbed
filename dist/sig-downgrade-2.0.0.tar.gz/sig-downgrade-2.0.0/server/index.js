module.exports = {
  async onLoad(ctx) { ctx.log?.info?.('sig-downgrade v2.0.0 loaded'); },
  routes: [{ method: 'GET', path: '/ping', auth: false, async handler() {
    return { status: 200, headers: { 'content-type': 'application/json' }, body: JSON.stringify({ id: 'sig-downgrade', version: '2.0.0' }) };
  }}],
};
