module.exports = {
  async onLoad(ctx) { ctx.log?.info?.('sig-signed v1.0.0 loaded'); },
  routes: [{ method: 'GET', path: '/ping', auth: false, async handler() {
    return { status: 200, headers: { 'content-type': 'application/json' }, body: JSON.stringify({ id: 'sig-signed', version: '1.0.0' }) };
  }}],
};
